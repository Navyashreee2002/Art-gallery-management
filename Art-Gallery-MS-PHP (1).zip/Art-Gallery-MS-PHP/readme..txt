How to run the Art Gallery Management System (agms) Project
1. Download the zip file

2. Extract the file and copy agms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name agmsdb

6. Import agmsdb.sql file(given inside the zip package in the SQL file folder)

7. Run the script http://localhost/agms

Credential for Admin panel :

Username: admin
Password: Test@123

