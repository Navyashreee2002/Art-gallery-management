 <div class="text-right">
        <div class="credits">
        <p>Art Gallery Management System.</p>
        </div>
      </div>